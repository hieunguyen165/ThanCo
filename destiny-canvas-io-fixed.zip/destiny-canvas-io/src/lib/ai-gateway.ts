// AI gateway — dùng Beeknoee (OpenAI-compatible) hoặc Gemini trực tiếp.
// Env var: BEEKNOEE_API_KEY (sk-bee-...) hoặc GEMINI_API_KEY (AIza...)
// Không còn phụ thuộc vào Lovable gateway.

export const BEEKNOEE_MODELS = ["gemini-2.5-flash-lite", "gemini-2.5-flash", "gemini-2.0-flash"];
export const GEMINI_DIRECT_MODELS = ["gemini-2.5-flash", "gemini-2.5-flash-lite", "gemini-2.0-flash"];

/** Gọi Beeknoee (OpenAI-compatible). Key phải bắt đầu bằng sk-bee- hoặc sk- */
export async function runViaBeeknoee(prompt: string, key: string): Promise<string> {
  let lastErr = "";
  for (const model of BEEKNOEE_MODELS) {
    try {
      const res = await fetch("https://platform.beeknoee.com/v1/chat/completions", {
        method: "POST",
        headers: { "content-type": "application/json", authorization: `Bearer ${key}` },
        body: JSON.stringify({
          model,
          messages: [{ role: "user", content: prompt }],
          max_tokens: 8192,
          temperature: 0.7,
        }),
      });
      if (res.ok) {
        const j = (await res.json()) as { choices?: Array<{ message?: { content?: string } }> };
        const text = j.choices?.[0]?.message?.content ?? "";
        if (text) return text;
        lastErr = "Beeknoee không trả về nội dung";
        continue;
      }
      lastErr = `Beeknoee ${model} ${res.status}: ${(await res.text()).slice(0, 200)}`;
    } catch (e) {
      lastErr = e instanceof Error ? e.message : String(e);
    }
  }
  throw new Error(lastErr || "Beeknoee không khả dụng");
}

/** Gọi Gemini API trực tiếp. Key dạng AIza... */
export async function runViaGemini(prompt: string, key: string): Promise<string> {
  let lastErr = "";
  for (const model of GEMINI_DIRECT_MODELS) {
    try {
      const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${encodeURIComponent(key)}`;
      const res = await fetch(url, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          contents: [{ parts: [{ text: prompt }] }],
          generationConfig: { maxOutputTokens: 8192, temperature: 0.7 },
        }),
      });
      if (res.ok) {
        const j = (await res.json()) as { candidates?: Array<{ content?: { parts?: Array<{ text?: string }> } }> };
        const text = j.candidates?.[0]?.content?.parts?.map((p) => p.text ?? "").join("") ?? "";
        if (text) return text;
        lastErr = "Gemini không trả về nội dung";
        continue;
      }
      lastErr = `Gemini ${model} ${res.status}: ${(await res.text()).slice(0, 200)}`;
    } catch (e) {
      lastErr = e instanceof Error ? e.message : String(e);
    }
  }
  throw new Error(lastErr || "Gemini không khả dụng");
}

/**
 * Hàm chính: tự chọn provider dựa vào env var.
 * Ưu tiên: BEEKNOEE_API_KEY → GEMINI_API_KEY
 */
export async function runAI(prompt: string, overrideKey?: string): Promise<string> {
  // Key override (từ DB admin settings) ưu tiên cao nhất
  if (overrideKey && overrideKey.trim()) {
    const k = overrideKey.trim();
    if (k.startsWith("sk-bee-") || k.startsWith("sk-")) return runViaBeeknoee(prompt, k);
    return runViaGemini(prompt, k);
  }

  // Env vars
  const beeknoeeKey = process.env.BEEKNOEE_API_KEY ?? "";
  if (beeknoeeKey.trim()) return runViaBeeknoee(prompt, beeknoeeKey.trim());

  const geminiKey = process.env.GEMINI_API_KEY ?? "";
  if (geminiKey.trim()) return runViaGemini(prompt, geminiKey.trim());

  throw new Error("Chưa cấu hình AI key. Thêm BEEKNOEE_API_KEY hoặc GEMINI_API_KEY vào environment variables.");
}

// Giữ export cũ để không phá các import hiện tại (noop — chỉ dùng runAI)
export const createLovableAiGatewayProvider = (_key: string) => {
  throw new Error("Lovable gateway đã bị xoá. Dùng runAI() thay thế.");
};
